<aside class="d-flex flex-column h-100 p-3 bg-white border-end">


    <nav class="nav nav-pills flex-column gap-2">

        <a class="nav-link link-dark d-flex align-items-center gap-3 px-3 @if (request()->routeIs('admin.dashboard')) bg-primary-subtle text-primary @endif"
           href="{{ route('admin.dashboard') }}">
            <i class="ri-dashboard-line fs-5"></i>
            <span class="fw-medium">Dashboard</span>
        </a>

        <a class="nav-link link-dark d-flex align-items-center gap-3 px-3 @if (request()->routeIs('admin.project.*')) bg-primary-subtle text-primary @endif"
           href="{{ route('admin.project.index') }}">
            <i class="ri-folder-3-line fs-5"></i>
            <span class="fw-medium">Projects</span>
        </a>

        <a class="nav-link d-flex link-dark align-items-center gap-3 px-3 @if (request()->routeIs('admin.profile.*')) bg-primary-subtle text-primary @endif"
           href="{{ route('admin.profile.index') }}" aria-current="page">
            <i class="ri-user-fill fs-5"></i>
            <span class="fw-medium">Profile</span>
        </a>

        <a class="nav-link d-flex link-dark align-items-center gap-3 px-3 @if (request()->routeIs('admin.testimonial.*')) bg-primary-subtle text-primary @endif"
           href="{{ route('admin.testimonial.index') }}"
           aria-current="page">
            <i class="ri-chat-quote-line fs-5"></i>
            <span class="fw-medium">Testimonials</span>
        </a>

    </nav>
</aside>
