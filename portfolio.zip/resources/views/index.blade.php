@extends('layouts.app')

@section('content')
    @include('themes.hero')
    @include('themes.projects')
    @include('themes.about')
    @include('themes.testimonial')
    @include('themes.contact')
@endsection
