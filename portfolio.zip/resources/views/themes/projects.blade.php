<section id="projects" class="py-5">
    <div class="container">
        <div class="d-flex flex-wrap justify-content-between align-items-end mb-4" data-aos="fade-up">
            <div>
                <h6 style="color:var(--accent); font-weight:bold; letter-spacing:1px;">PORTFOLIO</h6>
                <h2 class="fw-bold">Selected Projects</h2>
            </div>
        </div>

        <div class="swiper-container" data-aos="fade-up" data-aos-delay="100">
            <div class="swiper-wrapper">


                @if(count($user->projects) > 0)
                    @foreach($user->projects as $project)
                        <div class="swiper-slide">
                            <div class="project-card">
                                <div class="position-relative">
                                    <img loading="lazy" src="{{ $project->getFirstMediaUrl("app-image") }}"
                                         class="img-fluid w-100"
                                         style="height:200px; object-fit:cover;">
                                    <div class="project-badge">
                                        {{ ucwords(implode(" • ", $project->technology)) }}
                                    </div>
                                </div>
                                <div class="p-4">
                                    <h5 class="fw-bold">{{ $project->name }}</h5>
                                    <p class="small mb-3 opacity-75">{{ $project->short_description }}</p>
                                    <a href="#" class="text-decoration-none fw-bold" style="color:var(--accent)"
                                       data-bs-toggle="modal" data-bs-target="#foodModal">
                                        View Details <i class="fa-solid fa-arrow-right ms-1"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @else
                    Not Have Any Project
                @endif

            </div>
            <div class="swiper-pagination"></div>
        </div>
    </div>
</section>
